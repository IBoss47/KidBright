Blockly.Msg.ESPNOW_GET_MAC_MESSAGE = "ESP-NOW อ่านค่า MAC Address";
Blockly.Msg.ESPNOW_GET_MAC_TOOLTIP = "อ่านค่า MAC Address จากบอร์ด KidBright";

Blockly.Msg.ESPNOW_SEND_MESSAGE = "ESP-NOW ส่งข้อมูล %1";
Blockly.Msg.ESPNOW_SEND_TOOLTIP = "ส่งข้อมูลไปบอร์ด KidBright32 ตัวอื่นผ่าน ESP-NOW";

Blockly.Msg.ESPNOW_SEND2_MESSAGE = "ESP-NOW ส่งข้อมูล %1 ไปยัง %2";
Blockly.Msg.ESPNOW_SEND2_TOOLTIP = "ส่งข้อมูลไปยังบอร์ด KidBright32 ที่กำหนดผ่าน ESP-NOW";

Blockly.Msg.ESPNOW_RECV_MESSAGE = "ESP-NOW เมื่อได้รับข้อมูล %1 %2";
Blockly.Msg.ESPNOW_RECV_TOOLTIP = "โค้ดภายในบล็อกจะถูกทำเมื่อได้รับข้อมูลจากบอร์ด KidBright32 ตัวอื่นผ่าน ESP-NOW";

Blockly.Msg.ESPNOW_READ_STRING_MESSAGE = "ESP-NOW อ่านข้อความ";
Blockly.Msg.ESPNOW_READ_STRING_TOOLTIP = "อ่านข้อความที่ได้รับจากบอร์ด KidBright32 ตัวอื่นผ่าน ESP-NOW";

Blockly.Msg.ESPNOW_READ_NUMBER_MESSAGE = "ESP-NOW อ่านตัวเลข";
Blockly.Msg.ESPNOW_READ_NUMBER_TOOLTIP = "อ่านตัวเลขที่ได้รับจากบอร์ด KidBright32 ตัวอื่นผ่าน ESP-NOW";
